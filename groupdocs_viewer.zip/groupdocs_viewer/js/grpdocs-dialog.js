$(function(){
    // Get GroupDocs button to toolbar
    var toolbar = jQuery.get('#data_toolbar1');
    // Waiting for toolbar initialization
    toolbar.success(function(data) {
        // Add GroupDocs button to toolbar
        var icon = '<td style="position: relative"><a role="button" id="content_grpdocs" href="javascript:;" class="mceButton mceButtonEnabled mce_grpdocs" onmousedown="return false;" onclick="return false;" aria-labelledby="content_grpdocs_voice" title="GroupDocs Viewer Embedder" tabindex="-1"><span class="mceIcon mce_grpdocs"><img class="mceIcon" src="../e107_plugins/groupdocs_viewer/images/icon_16.png" alt="GroupDocs Viewer Embedder"></span><span class="mceVoiceLabel mceIconOnly" style="display: none;" id="content_grpdocs_voice">GroupDocs Viewer Embedder</span></a></td>';
        var data_toolbar1 = jQuery('#data_toolbar1');
        var last_child = data_toolbar1.find('.mceToolbarEnd');
        last_child.before(icon);
        
        // Toolbar button open action
        jQuery('#content_grpdocs').bind('click', function(){
            //var popupHtml = '<form id="form" onsubmit="" method="post" action="" enctype="multipart/form-data"><table id="info-wrapper"> <tr> <td align="right" class="gray dwl_gray"><strong>Client Id</strong><br /></td> <td valign="top"> <input name="userId" type="text" class="opt dwl" id="userId" style="width:200px;" value="" /><br/><span id="uri-note"></span> </td> </tr> <tr> <td align="right" class="gray dwl_gray"><strong>API Key</strong><br /></td> <td valign="top"> <input name="privateKey" type="text" class="opt dwl" id="privateKey" style="width:200px;" value="" /><br/><span id="uri-note"></span> </td> </tr> <tr> <td align="right" class="gray dwl_gray"><strong>Height</strong></td> <td valign="top" style="width:200px;"><input name="height" type="text" class="opt dwl" id="height" size="6" style="text-align:right" value="700" />px</td> </tr> <tr> <td align="right" class="gray dwl_gray"><strong>Width</strong></td> <td valign="top"><input name="width" type="text" class="opt dwl" id="width" size="6" style="text-align:right" value="600" />px</td> </tr> <tr> <td align="right" class="gray dwl_gray"><strong>Choose the protocol</strong></td> <td valign="top"><input type="radio" name="protocol" value="http" checked>http:// <input type="radio" name="protocol" value="https">https://</td> </tr></table><div class="section"><ul id="gd-tabs"> <li class="current">Browse &amp; Embed</li> <li>Upload &amp; Embed</li> <li>Paste GUID</li></ul><div class="box visible"> <strong>Select File</strong><br /> <span id="groupdocs_keys_error" style="display:none">WARNING: There is no user id and/or private key please enter them on GroupDocs Options page or fill marked fields and press <a href="#" onclick="loadFileTree(jQuery);return false">reload</a> </span> <div id="groupdocsBrowser"> <div id="groupdocsBrowserInner" > </div> </div></div><div class="box"> <strong>Upload Document</strong><br /> <input name="file" type="file" class="opt dwl" id="file" style="width:200px;" /><br/> <span id="uri-note"></span></div><div class="box"> <strong>Document Id (GUID)</strong><br /> <input name="url" type="text" class="opt dwl" id="url" style="width:200px;" /><br/> <span id="uri-note"></span></div></div><!-- .section --><fieldset> <table width="100%" border="0" cellspacing="0" cellpadding="5"> <tr> <td colspan="2"> <br /> Shortcode Preview <textarea name="shortcode" cols="72" rows="2" id="shortcode"></textarea> </td> </tr> </table></fieldset> <div class="mceActionPanel"> <div style="float: left"> <input type="button" id="gdInsertCode" name="insert" value="Insert"/> </div> <div style="float: right"> <input type="button" id="gdCancel" name="cancel" value="Cancel"/> </div> </div></form>';
            var popupHtml = '<div id="gd-dialog"><table id="info-wrapper"> <tr> <td align="right" class="gray dwl_gray"><strong>File ID</strong><br /></td> <td valign="top"> <input name="fileID" type="text" class="opt dwl" id="fileID" style="width:200px;" value="" /><br/><span id="uri-note"></span> </td> </tr> <tr> <td align="right" class="gray dwl_gray"><strong>Height</strong></td> <td valign="top" style="width:200px;"><input name="height" type="text" class="opt dwl" id="height" size="6" style="text-align:right" value="700" />px</td> </tr> <tr> <td align="right" class="gray dwl_gray"><strong>Width</strong></td> <td valign="top"><input name="width" type="text" class="opt dwl" id="width" size="6" style="text-align:right" value="600" />px</td> </tr> </table><div class="mceActionPanel"> <div style="float: left"> <input type="button" id="gdInsertCode" name="insert" value="Insert"/> </div> <div style="float: right"> <input type="button" id="gdCancel" name="cancel" value="Cancel"/> </div> </div></div>';
            jQuery('#grpdocs-popup').append(popupHtml);
            jQuery('#grpdocs-popup').toggle();
            
            // Dialog button insert
            jQuery('#gdInsertCode').bind('click', function(){
                var fileID = jQuery('#fileID').val();
                var width = jQuery('#width').val();
                var height = jQuery('#height').val();
                if(fileID!=null && fileID!='' && width!=null && width!='' && height!=null && height!=''){
                    var iframe = '<iframe src="http://apps.groupdocs.com/document-viewer/embed/'+fileID+'" frameborder="0" width="'+width+'" height="'+height+'"></iframe>';
                    jQuery('#tinymce', jQuery('#data_ifr').contents()).append(iframe);
                }
                jQuery('#gd-dialog').remove();
                jQuery('#grpdocs-popup').toggle();
            });

            // Dialog button close
            jQuery('#gdCancel').bind('click', function(){
                jQuery('#gd-dialog').remove();
                jQuery('#grpdocs-popup').toggle();
            });
        });

    });
    // Add popup wrapper
    jQuery('body').append('<div id="grpdocs-popup"><div id="grpdocs-dialog-header">GroupDocs Viewer Embedder</div></div>');
});