<?php
define("GDLAN_01", "Lets you embed PPT, PPTX, XLS, XLSX, DOC, DOCX, PDF and many other formats from your GroupDocs acount in a web page using the GroupDocs Embedded Viewer (no Flash or PDF browser plug-ins required).");
define("GDLAN_02", "Settings");
define("GDLAN_03", "Installation Successful...");
define("GDLAN_04", "Upgrade successful...");
define("GDLAN_05", "Save Changes");
define("GDLAN_06", "Changes were saved successfully.");
define("GDLAN_07", "Error: please fill all inputs!");
?>