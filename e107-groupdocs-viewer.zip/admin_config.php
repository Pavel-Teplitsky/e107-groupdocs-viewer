<?php
require_once("../../class2.php");
include_lan(e_PLUGIN . "groupdocs_viewer/languages/groupdocs_viewer_" . e_LANGUAGE . ".php");

require_once(e_ADMIN . "auth.php");
require_once(e_HANDLER . "form_handler.php");

// On save settings
if(isset($_POST['saveSettings'])){
    if($_POST['userId'] && $_POST['privateKey']){
        $sql->db_Update("groupdocs_viewer", "userId='".$_POST['userId']."', privateKey='".$_POST['privateKey']."' WHERE 1");
        $message = GDLAN_06;
    }else{
        $message = GDLAN_07;
    }
}

// If message exists
if (isset($message)) {
    $ns->tablerender("", "<div style='text-align:center'><b>".$message."</b></div>");
}

$userID = '';
$privateKey = '';

// Get data from DB
if($sql->db_Select("groupdocs_viewer")){
    $row = $sql->db_Fetch();
    $userID = $row['userId'];
    $privateKey = $row['privateKey'];
}

$body = '<div>
    <form name="form" method="post" action="">
        <input type="hidden" name="grpdocs_submit_hidden" value="1">
        <table class="fborder" style="'.ADMIN_WIDTH.'">
            <tr>
                <td class="forumheader3" style="width:30%; white-space:nowrap;">User Id:</td>
                <td class="forumheader3" style="width:70%;">
                    <input class="tbox" type="text" name="userId" value="'.$userID.'" size="74" maxlength="250">
                </td>
            </tr>
            <tr>
                <td class="forumheader3" style="width:30%; white-space:nowrap;">Private Key:</td>
                <td class="forumheader3" style="width:70%;">
                    <input class="tbox" type="text" name="privateKey" value="'.$privateKey.'" size="74" maxlength="250">
                </td>
            </tr>
        </table>
        <div style="text-align:center;">
            <input type="submit" name="saveSettings" class="button" value="'.GDLAN_05.'" />
        </div>
    </form>
</div>';
$ns -> tablerender(GDLAN_02, $body);

require_once(e_ADMIN."footer.php");
?>