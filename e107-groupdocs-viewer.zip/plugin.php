<?php

include_lan(e_PLUGIN."groupdocs_viewer/languages/groupdocs_viewer_".e_LANGUAGE.".php");

// Plugin info
$eplug_name = "GroupDocs Viewer";
$eplug_version = "1.0";
$eplug_author = "GroupDocs Team";
$eplug_url = "http://www.groupdocs.com";
$eplug_email = "support@groupdocs.com";
$eplug_description = GDLAN_01;
$eplug_compatible = "e107v0.7+";
$eplug_readme = "readme.txt";
$eplug_compliant = TRUE;
$eplug_link = FALSE;
$eplug_done = GDLAN_03;
$eplug_upgrade_done = GDLAN_04;

// Plugin directories
$eplug_folder = "groupdocs_viewer";
$eplug_icon = $eplug_folder."/images/icon_32.png";
$eplug_icon_small = $eplug_folder."/images/icon_16.png";

// Plugin config file
$eplug_conffile = "admin_config.php";
$eplug_caption = GDLAN_02;

// List of preferences
$eplug_prefs = array(
'groupdocs_viewer_version' => $eplug_version 
);

// Plugin Update
if(!function_exists("groupdocs_viewer_upgrade")){
    function groupdocs_viewer_upgrade(){
        $upgrade_add_prefs = array(
        'groupdocs_viewer_version' => $eplug_version 
        );	
    }
}
// Plugin Install
if (($pref['plug_installed']['groupdocs_viewer'])  == "1.0") {
    $upgrade_add_prefs = array(
    'groupdocs_viewer_version' => $eplug_version 
    );		
    $eplug_upgrade_done = GDLAN_03 . $eplug_version;
}
// Plugin Remove
if(!function_exists("groupdocs_viewer_uninstall")){
    function groupdocs_viewer_uninstall()	{
        $upgrade_remove_prefs = array(
        'groupdocs_viewer_version' ,
        );	
    }
}
// Plugin tables
$eplug_table_names = array("groupdocs_viewer");

$eplug_tables = array(
   "CREATE TABLE ".MPREFIX."groupdocs_viewer (
      userId          varchar(100)   NOT NULL default '',
      privateKey      varchar(100)   NOT NULL default ''
   )  ENGINE=MyISAM ;");
?>