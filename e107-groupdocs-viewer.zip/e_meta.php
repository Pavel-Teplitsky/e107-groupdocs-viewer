<?php
    echo '<script type="text/javascript" src="'.e_PLUGIN.'groupdocs_viewer/js/jquery-1.9.1.min.js"></script>';
    echo '<script type="text/javascript" src="'.e_PLUGIN.'groupdocs_viewer/js/grpdocs-dialog.js"></script>';
    echo '<link type="text/css" rel="stylesheet" href="'.e_PLUGIN.'groupdocs_viewer/css/grpdocs-dialog.css"/>';
?>